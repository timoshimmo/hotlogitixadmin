import MuiButton from './MuiButton';

export default {
  MuiButton
};
