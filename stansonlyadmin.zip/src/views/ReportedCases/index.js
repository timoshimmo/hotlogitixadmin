export { default } from './ReportedCases';
